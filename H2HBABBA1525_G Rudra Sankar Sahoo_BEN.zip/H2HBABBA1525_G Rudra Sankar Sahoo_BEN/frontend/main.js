const addbutton = document.getElementById("add-btn");
const editbutton = document.getElementById("edit-btn");
const deletebutton = document.getElementById("delete-btn");

const closeAdd = document.getElementsByClassName("close-btn")[0];
const closeEdit = document.getElementsByClassName("close-btn")[1];
const closeDelete = document.getElementsByClassName("close-btn")[2];



// Showing Popups
addbutton.addEventListener("click", openAddModel);
editbutton.addEventListener("click", openEditModel);
deletebutton.addEventListener("click", openDeleteModel);

function openAddModel() {
  document.querySelector(".add-popup").style.display = "flex";
  document.querySelector("#model-add").style.visibility = "visible";
}
function openEditModel() {
  document.querySelector(".edit-popup").style.display = "flex";
  document.querySelector(".model-edit").style.visibility = "visible";
}
function openDeleteModel() {
  document.querySelector(".delete-popup").style.display = "flex";
  document.querySelector(".model-delete").style.visibility = "visible";
}

// Hide Popups
closeAdd.addEventListener("click", closeAddPopup);
closeEdit.addEventListener("click", closeEditPopup);
closeDelete.addEventListener("click", closeDeletePopup);

function closeAddPopup() {
  document.querySelector(".add-popup").style.display = "none";
  document.querySelector("#model-add").style.visibility = "hidden";
}
function closeEditPopup() {
  document.querySelector(".edit-popup").style.display = "none";
  document.querySelector(".model-edit").style.visibility = "hidden";
}
function closeDeletePopup() {
  document.querySelector(".delete-popup").style.display = "none";
  document.querySelector(".model-delete").style.visibility = "hidden";
}


fetch("http://localhost:8080/H2HBABBA1525/dummy.do").then((res) => {
	  res.json().then(data => {
	    console.log(data);
	    if(data.length>0){
	    	var temp="";
	    	let x="checkbox";
	    	let classCheckBox="check-box";
	    	data.forEach((u)=>{
	    		temp+="<tr>";
	    	    temp+="<td><input type="+x+" class="+classCheckBox+"></td>";
	    		temp+="<td>"+u.Name_customer+"</td>";
	    		temp+="<td>"+u.Cust_number+"</td>";
	    		temp+="<td>"+u.Invoice_id+"</td>";
	    		temp+="<td>"+u.Total_open_amount+"</td>";
	    		temp+="<td>"+u.Due_in_date+"</td>";
	    		temp+="<td>"+u.Predicted_clear_date+"</td>";
	    		temp+="<td>Lorem ipsum dolor sit.</td></tr>";
	    		
	    	});
	    	document.getElementById("data").innerHTML = temp;
	    }
	  });
	});
