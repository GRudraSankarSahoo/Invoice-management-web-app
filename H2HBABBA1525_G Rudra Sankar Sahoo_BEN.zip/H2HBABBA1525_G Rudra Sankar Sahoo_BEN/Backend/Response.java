package com.higradius;

public class Response {
	private String Name_customer;
	private int Cust_number;
	private int Invoice_id;
	private String Due_in_date;
	private String Predicted_clear_date;
	private int Total_open_amount;
	public String getName_customer() {
		return Name_customer;
	}
	public void setName_customer(String name_customer) {
		Name_customer = name_customer;
	}
	public int getCust_number() {
		return Cust_number;
	}
	public void setCust_number(int cust_number) {
		Cust_number = cust_number;
	}
	public int getInvoice_id() {
		return Invoice_id;
	}
	public void setInvoice_id(int invoice_id) {
		Invoice_id = invoice_id;
	}
	public String getDue_in_date() {
		return Due_in_date;
	}
	public void setDue_in_date(String due_in_date) {
		Due_in_date = due_in_date;
	}
	public String getPredicted_clear_date() {
		return Predicted_clear_date;
	}
	public void setPredicted_clear_date(String predicted_clear_date) {
		Predicted_clear_date = predicted_clear_date;
	}
	public int getTotal_open_amount() {
		return Total_open_amount;
	}
	public void setTotal_open_amount(int total_open_amount) {
		Total_open_amount = total_open_amount;
	}
	
	
	
	
}
