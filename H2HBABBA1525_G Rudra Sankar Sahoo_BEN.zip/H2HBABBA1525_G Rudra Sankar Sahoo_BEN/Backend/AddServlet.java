package com.higradius;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AddServlet
 */
@WebServlet("/AddServlet")
public class AddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://localhost:3306/my_dB";
	
	static final String USER = "root";
	static final String PASSWORD = "root";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Connection conn = null;
		Statement stmt = null;
		String name_customer=request.getParameter("name_customer");
		String cust_number=request.getParameter("cust_number");
		String invoice_id=request.getParameter("invoice_id");
		String invoice_amount=request.getParameter("invoice_amount");
		String due_in_date=request.getParameter("due_in_date");
		String predicted_clear_date="0000-00-00";
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(DB_URL,USER,PASSWORD);
			stmt=conn.createStatement();
			String sql;
			sql="insert into mytable(cust_number,name_customer,due_in_date,total_open_amount,invoice_id,predicted_clear_date) values("+"'"+cust_number+"'"+","+"'"+name_customer+"'"+","+"'"+due_in_date+"'"+","+"'"+invoice_amount+"'"+","+"'"+invoice_id+"'"+","+"'"+predicted_clear_date+"'"+")";
			int rs=stmt.executeUpdate(sql);
			System.out.print(rs);
			 
			 stmt.close();
			 conn.close();
			 response.sendRedirect("http://localhost:8080/H2HBABBA1525/index.html");
	}catch(SQLException se){
		se.printStackTrace();
		}catch(Exception e){
		//Handle errors for Class.forName
		e.printStackTrace();
		}
	}

}